<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f7f7f7; }
        .container { max-width: 800px; margin: 40px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); }
        .nav { text-align: right; padding: 10px; }
        .nav a { color: #333; text-decoration: none; margin-left: 15px; }
        .nav a:hover { text-decoration: underline; }
        .welcome-content { text-align: center; margin-top: 40px; }
    </style>
</head>
<body>
    <div class="container">
        @if (Route::has('login'))
            <div class="nav">
                @auth
                    <a href="{{ url('/dashboard') }}">Dashboard</a>
                @else
                    <a href="{{ route('login') }}">Log in</a>
                    @if (Route::has('register'))
                        <a href="{{ route('register') }}">Register</a>
                    @endif
                @endauth
            </div>
        @endif

        <div class="welcome-content">
            <h1>Welcome to Laravel</h1>
            <p>Your authentication system is ready!</p>
        </div>
    </div>
</body>
</html>