<?php

use App\Http\Controllers\UserController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// O singură definire pentru dashboard
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

// Rute pentru profil
Route::middleware(['auth'])->group(function () {
    // Ruta pentru dashboard-ul personal
    Route::get('/dashboard', [UserController::class, 'showDashboard'])
        ->name('dashboard');

    // Rute pentru administratori
    Route::middleware(['can:view-users'])->group(function () {
        Route::get('/users', [UserController::class, 'index'])->name('users.index');
        Route::get('/dashboard/{user}', [UserController::class, 'showDashboard'])
            ->name('dashboard.user');
    });
});
// Includem rutele de autentificare
require __DIR__.'/auth.php';