<!DOCTYPE html>
<html>
<head>
    <title>Personal Dashboard</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background: #f7f7f7; 
        }
        .container { 
            max-width: 800px; 
            margin: 40px auto; 
            padding: 20px; 
            background: white; 
            border-radius: 8px; 
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); 
        }
        .user-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: #fff;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #dee2e6;
        }
        .logout-form { 
            display: inline; 
        }
        .logout-button { 
            background: #dc3545; 
            color: white; 
            padding: 8px 16px; 
            border: none; 
            border-radius: 4px; 
            cursor: pointer; 
        }
        .logout-button:hover { 
            background: #c82333; 
        }
        .nav {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav">
            <h1>Personal Dashboard</h1>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="logout-form">
                <?php echo csrf_field(); ?>
                <button type="submit" class="logout-button">Logout</button>
            </form>
        </div>

        <div class="user-info">
            <h2>Welcome, <?php echo e($user->name); ?>!</h2>
            <p>Email: <?php echo e($user->email); ?></p>
            <p>Role: <?php echo e(ucfirst($user->role)); ?></p>
            <p>Member since: <?php echo e($user->created_at->format('F d, Y')); ?></p>
        </div>

        <div class="stats">
            <div class="stat-card">
                <h3>Account Status</h3>
                <p>Active</p>
            </div>
            <div class="stat-card">
                <h3>Last Login</h3>
                <p><?php echo e(now()->format('F d, Y H:i')); ?></p>
            </div>
            <div class="stat-card">
                <h3>Email Status</h3>
                <p><?php echo e(auth()->user()->email_verified_at ? 'Verified' : 'Not Verified'); ?></p>
            </div>
        </div>

        <div class="nav">
            <?php if(auth()->user()->isAdmin()): ?>
                <a href="<?php echo e(route('users.index')); ?>" style="margin-right: 15px;">Manage Users</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\auth-project\resources\views/dashboard.blade.php ENDPATH**/ ?>