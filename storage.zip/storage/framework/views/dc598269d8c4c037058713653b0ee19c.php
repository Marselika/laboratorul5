<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f7f7f7; }
        .container { max-width: 800px; margin: 40px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); }
        .nav { text-align: right; padding: 10px; }
        .nav a { color: #333; text-decoration: none; margin-left: 15px; }
        .nav a:hover { text-decoration: underline; }
        .welcome-content { text-align: center; margin-top: 40px; }
    </style>
</head>
<body>
    <div class="container">
        <?php if(Route::has('login')): ?>
            <div class="nav">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">Log in</a>
                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="welcome-content">
            <h1>Welcome to Laravel</h1>
            <p>Your authentication system is ready!</p>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\auth-project\resources\views/welcome.blade.php ENDPATH**/ ?>